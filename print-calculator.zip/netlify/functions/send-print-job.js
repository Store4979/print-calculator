// netlify/functions/send-print-job.js
const nodemailer = require('nodemailer');

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const { subject, to, jobType, details, pdfBase64 } = JSON.parse(event.body || '{}');

    if (!pdfBase64) {
      return { statusCode: 400, body: 'Missing PDF data' };
    }

    // Configure SMTP using environment variables on Netlify
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: false,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
      }
    });

    const info = await transporter.sendMail({
      from: '"Print Calculator" <no-reply@yourdomain.com>',
      to: to || 'store4979@theupsstore.com',
      subject: subject || 'PRINT JOB',
      text:
        `Job type: ${jobType}\n\nDetails:\n` +
        JSON.stringify(details, null, 2),
      attachments: [
        {
          filename: jobType === 'large-format' ? 'large-format.pdf' : 'print-job.pdf',
          content: pdfBase64,
          encoding: 'base64'
        }
      ]
    });

    return {
      statusCode: 200,
      body: JSON.stringify({ ok: true, messageId: info.messageId })
    };
  } catch (err) {
    console.error(err);
    return {
      statusCode: 500,
      body: JSON.stringify({ ok: false, error: err.message })
    };
  }
};
